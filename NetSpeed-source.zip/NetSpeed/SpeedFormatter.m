//
//  SpeedFormatter.m
//  NetSpeedMonitor
//
//  Created for macOS (Apple Silicon M4 Native).
//

#import "SpeedFormatter.h"

@interface SpeedFormatter ()
@property (nonatomic, strong) NSFont *verticalFont;
@property (nonatomic, strong) NSFont *horizontalFont;
@property (nonatomic, strong) NSMutableParagraphStyle *verticalParagraphStyle;
@end

@implementation SpeedFormatter

+ (instancetype)sharedFormatter {
    static SpeedFormatter *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[SpeedFormatter alloc] init];
    });
    return instance;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        // 使用真正的全等宽系统字体 (SF Mono)，确保数字、小数点、空格、字母宽度完全绝对一致
        _verticalFont = [NSFont monospacedSystemFontOfSize:9.0 weight:NSFontWeightMedium];
        _horizontalFont = [NSFont monospacedSystemFontOfSize:11.0 weight:NSFontWeightMedium];
        
        _verticalParagraphStyle = [[NSMutableParagraphStyle alloc] init];
        _verticalParagraphStyle.alignment = NSTextAlignmentLeft;
        _verticalParagraphStyle.lineBreakMode = NSLineBreakByClipping;
        _verticalParagraphStyle.lineSpacing = -1.0;
        _verticalParagraphStyle.maximumLineHeight = 10.0;
        _verticalParagraphStyle.minimumLineHeight = 10.0;
    }
    return self;
}

- (NSString *)formatSpeed:(double)bytesPerSec {
    if (bytesPerSec < 0) {
        bytesPerSec = 0;
    }
    
    double kb = bytesPerSec / 1024.0;
    // 速率极低或为0时，严格保留一位小数："  0.0 KB/s"
    if (kb < 0.05) {
        return @"  0.0 KB/s";
    }
    
    // 小于 1000 KB/s，保留一位小数，固定占 5 字符 (例如 "  8.2", " 13.5", "120.5")
    if (kb < 999.95) {
        return [NSString stringWithFormat:@"%5.1f KB/s", kb];
    }
    
    // 超过 999.95 KB/s，自动进位为 MB/s
    double mb = kb / 1024.0;
    if (mb < 999.95) {
        return [NSString stringWithFormat:@"%5.1f MB/s", mb];
    }
    
    // 超过 999.95 MB/s，自动进位为 GB/s
    double gb = mb / 1024.0;
    return [NSString stringWithFormat:@"%5.1f GB/s", gb];
}

- (NSString *)formatDataSize:(uint64_t)bytes {
    if (bytes < 1024) {
        return [NSString stringWithFormat:@"%llu B", bytes];
    }
    double kb = (double)bytes / 1024.0;
    if (kb < 1024.0) {
        return [NSString stringWithFormat:@"%.1f KB", kb];
    }
    double mb = kb / 1024.0;
    if (mb < 1024.0) {
        return [NSString stringWithFormat:@"%.1f MB", mb];
    }
    double gb = mb / 1024.0;
    return [NSString stringWithFormat:@"%.2f GB", gb];
}

- (NSString *)formattedTextWithSpeed:(double)speed isUpload:(BOOL)isUpload arrowStyle:(ArrowStyle)arrowStyle {
    NSString *arrow = @"";
    if (isUpload) {
        arrow = (arrowStyle == ArrowStyleTriangle) ? @"▲" : @"↑";
    } else {
        arrow = (arrowStyle == ArrowStyleTriangle) ? @"▼" : @"↓";
    }
    return [NSString stringWithFormat:@"%@%@", arrow, [self formatSpeed:speed]];
}

- (NSAttributedString *)attributedStatusBarTitleWithUploadSpeed:(double)upSpeed
                                                  downloadSpeed:(double)downSpeed
                                                    displayMode:(DisplayMode)displayMode
                                                     arrowStyle:(ArrowStyle)arrowStyle {
    NSString *upArrow = (arrowStyle == ArrowStyleTriangle) ? @"▲" : @"↑";
    NSString *downArrow = (arrowStyle == ArrowStyleTriangle) ? @"▼" : @"↓";
    
    NSString *upStr = [self formatSpeed:upSpeed];
    NSString *downStr = [self formatSpeed:downSpeed];
    
    if (displayMode == DisplayModeVerticalTwoLines) {
        // 双行垂直模式
        NSString *fullText = [NSString stringWithFormat:@"%@ %@\n%@ %@", upArrow, upStr, downArrow, downStr];
        NSDictionary *attrs = @{
            NSFontAttributeName: self.verticalFont,
            NSParagraphStyleAttributeName: self.verticalParagraphStyle,
            NSForegroundColorAttributeName: [NSColor labelColor]
        };
        return [[NSAttributedString alloc] initWithString:fullText attributes:attrs];
    } else {
        // 单行水平模式
        NSString *fullText = [NSString stringWithFormat:@"%@ %@  %@ %@", upArrow, upStr, downArrow, downStr];
        NSDictionary *attrs = @{
            NSFontAttributeName: self.horizontalFont,
            NSForegroundColorAttributeName: [NSColor labelColor]
        };
        return [[NSAttributedString alloc] initWithString:fullText attributes:attrs];
    }
}

@end
