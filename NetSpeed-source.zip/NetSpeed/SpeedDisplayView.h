//
//  SpeedDisplayView.h
//  NetSpeedMonitor
//
//  Created for macOS (Apple Silicon M4 Native).
//

#import <Cocoa/Cocoa.h>
#import "SpeedFormatter.h"

NS_ASSUME_NONNULL_BEGIN

@interface SpeedDisplayView : NSView

@property (nonatomic, copy) NSString *upText;
@property (nonatomic, copy) NSString *downText;
@property (nonatomic, assign) DisplayMode displayMode;

- (void)updateWithUpText:(NSString *)upText
                downText:(NSString *)downText
             displayMode:(DisplayMode)displayMode;

@end

NS_ASSUME_NONNULL_END
