//
//  AppDelegate.h
//  NetSpeedMonitor
//
//  Created for macOS (Apple Silicon M4 Native).
//

#import <Cocoa/Cocoa.h>

NS_ASSUME_NONNULL_BEGIN

@interface AppDelegate : NSObject <NSApplicationDelegate, NSMenuDelegate>

@end

NS_ASSUME_NONNULL_END
