//
//  LaunchAtLogin.m
//  NetSpeedMonitor
//
//  Created for macOS (Apple Silicon M4 Native).
//

#import "LaunchAtLogin.h"
#import <ServiceManagement/ServiceManagement.h>

static NSString * const kLaunchAgentLabel = @"com.curie.netspeedmonitor";

@implementation LaunchAtLogin

+ (instancetype)sharedManager {
    static LaunchAtLogin *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[LaunchAtLogin alloc] init];
    });
    return instance;
}

- (NSString *)launchAgentPlistPath {
    NSString *launchAgentsDir = [@"~/Library/LaunchAgents" stringByExpandingTildeInPath];
    return [launchAgentsDir stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.plist", kLaunchAgentLabel]];
}

- (BOOL)isEnabled {
    if (@available(macOS 13.0, *)) {
        SMAppService *service = [SMAppService mainAppService];
        if (service.status == SMAppServiceStatusEnabled) {
            return YES;
        }
    }
    
    // 检查 LaunchAgent 文件是否存在
    NSString *plistPath = [self launchAgentPlistPath];
    return [[NSFileManager defaultManager] fileExistsAtPath:plistPath];
}

- (BOOL)setEnabled:(BOOL)enabled error:(NSError * _Nullable * _Nullable)error {
    // 优先尝试现代 SMAppService
    if (@available(macOS 13.0, *)) {
        SMAppService *service = [SMAppService mainAppService];
        if (enabled) {
            if (service.status != SMAppServiceStatusEnabled) {
                NSError *smError = nil;
                BOOL success = [service registerAndReturnError:&smError];
                if (success) {
                    return YES;
                }
                // 如果 SMAppService 未能成功（例如未签名或不在 /Applications），降级使用 LaunchAgent
            } else {
                return YES;
            }
        } else {
            if (service.status == SMAppServiceStatusEnabled) {
                [service unregisterAndReturnError:nil];
            }
        }
    }
    
    // 使用 LaunchAgent 机制
    NSString *plistPath = [self launchAgentPlistPath];
    NSFileManager *fm = [NSFileManager defaultManager];
    
    if (enabled) {
        NSString *launchAgentsDir = [@"~/Library/LaunchAgents" stringByExpandingTildeInPath];
        if (![fm fileExistsAtPath:launchAgentsDir]) {
            [fm createDirectoryAtPath:launchAgentsDir withIntermediateDirectories:YES attributes:nil error:nil];
        }
        
        NSString *appPath = [[NSBundle mainBundle] bundlePath];
        NSString *binaryPath = [[NSBundle mainBundle] executablePath];
        if (!binaryPath) {
            binaryPath = [appPath stringByAppendingPathComponent:@"Contents/MacOS/NetSpeedMonitor"];
        }
        
        NSDictionary *plistDict = @{
            @"Label": kLaunchAgentLabel,
            @"ProgramArguments": @[binaryPath],
            @"RunAtLoad": @YES,
            @"KeepAlive": @NO,
            @"ProcessType": @"Interactive"
        };
        
        return [plistDict writeToFile:plistPath atomically:YES];
    } else {
        if ([fm fileExistsAtPath:plistPath]) {
            return [fm removeItemAtPath:plistPath error:error];
        }
        return YES;
    }
}

@end
