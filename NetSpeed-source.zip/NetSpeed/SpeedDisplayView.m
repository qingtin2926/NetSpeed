//
//  SpeedDisplayView.m
//  NetSpeedMonitor
//
//  Created for macOS (Apple Silicon M4 Native).
//

#import "SpeedDisplayView.h"

@implementation SpeedDisplayView

- (instancetype)initWithFrame:(NSRect)frameRect {
    self = [super initWithFrame:frameRect];
    if (self) {
        _upText = @"▲   0 KB/s";
        _downText = @"▼   0 KB/s";
        _displayMode = DisplayModeVerticalTwoLines;
        self.autoresizingMask = NSViewWidthSizable | NSViewHeightSizable;
    }
    return self;
}

// 鼠标事件完全穿透给 superview (NSStatusBarButton)，保留系统原生点击与菜单弹出行为
- (NSView *)hitTest:(NSPoint)point {
    return nil;
}

- (void)updateWithUpText:(NSString *)upText
                downText:(NSString *)downText
             displayMode:(DisplayMode)displayMode {
    if (![_upText isEqualToString:upText] ||
        ![_downText isEqualToString:downText] ||
        _displayMode != displayMode) {
        _upText = [upText copy];
        _downText = [downText copy];
        _displayMode = displayMode;
        [self setNeedsDisplay:YES];
    }
}

- (void)drawRect:(NSRect)dirtyRect {
    [super drawRect:dirtyRect];
    
    NSRect bounds = self.bounds;
    if (bounds.size.width <= 0 || bounds.size.height <= 0) return;
    
    // 判断父视图 NSStatusBarButton 是否处于高亮点击状态
    BOOL isHighlighted = NO;
    if ([self.superview isKindOfClass:[NSButton class]]) {
        isHighlighted = ((NSButton *)self.superview).isHighlighted;
    }
    NSColor *textColor = isHighlighted ? [NSColor selectedMenuItemTextColor] : [NSColor labelColor];
    
    if (self.displayMode == DisplayModeVerticalTwoLines) {
        NSFont *font = [NSFont monospacedSystemFontOfSize:9.0 weight:NSFontWeightMedium];
        
        NSMutableParagraphStyle *style = [[NSMutableParagraphStyle alloc] init];
        style.alignment = NSTextAlignmentLeft;
        style.lineBreakMode = NSLineBreakByClipping;
        
        NSDictionary *attrs = @{
            NSFontAttributeName: font,
            NSForegroundColorAttributeName: textColor,
            NSParagraphStyleAttributeName: style
        };
        
        CGFloat rowHeight = 9.5;
        CGFloat lineSpacing = 1.0;
        CGFloat totalHeight = rowHeight * 2 + lineSpacing; // 20.0 pt
        
        // 关键居中算法：严格计算垂直坐标，使两行内容在状态栏高度 (22~24pt) 内上下完全居中对称
        CGFloat startY = floor((bounds.size.height - totalHeight) / 2.0) + 0.5;
        
        CGFloat leftPadding = 0.5;
        CGFloat textWidth = bounds.size.width - leftPadding;
        
        NSRect downRect = NSMakeRect(leftPadding, startY, textWidth, rowHeight);
        NSRect upRect = NSMakeRect(leftPadding, startY + rowHeight + lineSpacing, textWidth, rowHeight);
        
        [self.downText drawInRect:downRect withAttributes:attrs];
        [self.upText drawInRect:upRect withAttributes:attrs];
    } else {
        // 单行水平模式
        NSFont *font = [NSFont monospacedSystemFontOfSize:11.0 weight:NSFontWeightMedium];
        NSDictionary *attrs = @{
            NSFontAttributeName: font,
            NSForegroundColorAttributeName: textColor
        };
        
        NSString *combined = [NSString stringWithFormat:@"%@  %@", self.upText, self.downText];
        NSSize textSize = [combined sizeWithAttributes:attrs];
        
        CGFloat startY = floor((bounds.size.height - textSize.height) / 2.0);
        CGFloat leftPadding = 4.0;
        NSRect rect = NSMakeRect(leftPadding, startY, bounds.size.width - leftPadding, textSize.height);
        
        [combined drawInRect:rect withAttributes:attrs];
    }
}

@end
