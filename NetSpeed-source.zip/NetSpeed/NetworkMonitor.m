//
//  NetworkMonitor.m
//  NetSpeedMonitor
//
//  Created for macOS (Apple Silicon M4 Native).
//

#import "NetworkMonitor.h"
#import <sys/types.h>
#import <sys/socket.h>
#import <net/if.h>
#import <net/if_dl.h>
#import <ifaddrs.h>
#import <mach/mach_time.h>

@interface NetworkMonitor ()

@property (nonatomic, assign) double downloadSpeedBytesPerSec;
@property (nonatomic, assign) double uploadSpeedBytesPerSec;
@property (nonatomic, assign) uint64_t sessionTotalDownloadBytes;
@property (nonatomic, assign) uint64_t sessionTotalUploadBytes;
@property (nonatomic, copy) NSString *activeInterfaceName;

// 上一次各网卡的 32 位字节计数缓存，用于精确处理单网卡溢出绕回
@property (nonatomic, strong) NSMutableDictionary<NSString *, NSNumber *> *lastInMap;
@property (nonatomic, strong) NSMutableDictionary<NSString *, NSNumber *> *lastOutMap;
@property (nonatomic, assign) NSTimeInterval lastSampleTimestamp;
@property (nonatomic, assign) BOOL isFirstSample;

@end

@implementation NetworkMonitor

+ (instancetype)sharedMonitor {
    static NetworkMonitor *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[NetworkMonitor alloc] init];
    });
    return instance;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        _onlyPhysicalInterfaces = YES;
        _lastInMap = [NSMutableDictionary dictionary];
        _lastOutMap = [NSMutableDictionary dictionary];
        _isFirstSample = YES;
        _activeInterfaceName = @"en0";
        [self sampleSpeed];
    }
    return self;
}

- (void)resetSessionCounters {
    @synchronized (self) {
        _sessionTotalDownloadBytes = 0;
        _sessionTotalUploadBytes = 0;
    }
}

- (void)sampleSpeed {
    NSTimeInterval now = [NSDate timeIntervalSinceReferenceDate];
    
    struct ifaddrs *ifaddr = NULL;
    if (getifaddrs(&ifaddr) != 0 || ifaddr == NULL) {
        return;
    }
    
    NSMutableDictionary<NSString *, NSNumber *> *currentInMap = [NSMutableDictionary dictionary];
    NSMutableDictionary<NSString *, NSNumber *> *currentOutMap = [NSMutableDictionary dictionary];
    
    NSString *bestInterface = nil;
    uint32_t maxActivity = 0;
    
    for (struct ifaddrs *ifa = ifaddr; ifa != NULL; ifa = ifa->ifa_next) {
        if (!ifa->ifa_addr || ifa->ifa_addr->sa_family != AF_LINK) {
            continue;
        }
        
        unsigned int flags = ifa->ifa_flags;
        if (!(flags & IFF_UP) || !(flags & IFF_RUNNING) || (flags & IFF_LOOPBACK)) {
            continue;
        }
        
        const char *cName = ifa->ifa_name;
        if (!cName) continue;
        NSString *name = [NSString stringWithUTF8String:cName];
        
        // 过滤网络接口
        if (_onlyPhysicalInterfaces) {
            // 仅统计 en (Wi-Fi/以太网) 和 pdp_ip (蜂窝共享)，避免代理/VPN (utun) 双重计算
            if (![name hasPrefix:@"en"] && ![name hasPrefix:@"pdp_ip"]) {
                continue;
            }
        } else {
            // 统计所有非 loopback/非 awdl/非 bridge
            if ([name hasPrefix:@"awdl"] || [name hasPrefix:@"llw"] || [name hasPrefix:@"bridge"]) {
                continue;
            }
        }
        
        struct if_data *ifd = (struct if_data *)ifa->ifa_data;
        if (!ifd) continue;
        
        uint32_t ibytes = ifd->ifi_ibytes;
        uint32_t obytes = ifd->ifi_obytes;
        
        currentInMap[name] = @(ibytes);
        currentOutMap[name] = @(obytes);
        
        if (ibytes + obytes > maxActivity) {
            maxActivity = ibytes + obytes;
            bestInterface = name;
        }
    }
    
    freeifaddrs(ifaddr);
    
    if (bestInterface) {
        _activeInterfaceName = bestInterface;
    }
    
    if (_isFirstSample) {
        _lastInMap = currentInMap;
        _lastOutMap = currentOutMap;
        _lastSampleTimestamp = now;
        _isFirstSample = NO;
        _downloadSpeedBytesPerSec = 0;
        _uploadSpeedBytesPerSec = 0;
        return;
    }
    
    NSTimeInterval deltaTime = now - _lastSampleTimestamp;
    if (deltaTime <= 0.05) {
        return; // 时间间隔太短，跳过防止抖动
    }
    
    uint64_t totalDeltaIn = 0;
    uint64_t totalDeltaOut = 0;
    
    // 计算每个接口的增量并累加
    for (NSString *interface in currentInMap) {
        uint32_t curIn = [currentInMap[interface] unsignedIntValue];
        uint32_t curOut = [currentOutMap[interface] unsignedIntValue];
        
        NSNumber *prevInNum = _lastInMap[interface];
        NSNumber *prevOutNum = _lastOutMap[interface];
        
        if (prevInNum && prevOutNum) {
            uint32_t prevIn = [prevInNum unsignedIntValue];
            uint32_t prevOut = [prevOutNum unsignedIntValue];
            
            // 处理 32 位溢出回绕 (wrap-around)
            uint64_t dIn = (curIn >= prevIn) ? (curIn - prevIn) : ((uint64_t)UINT32_MAX - prevIn + curIn + 1);
            uint64_t dOut = (curOut >= prevOut) ? (curOut - prevOut) : ((uint64_t)UINT32_MAX - prevOut + curOut + 1);
            
            // 单秒单接口增量超过 10GB 视为异常跳变（例如休眠唤醒），予以平滑忽略
            if (dIn < 10ULL * 1024 * 1024 * 1024) {
                totalDeltaIn += dIn;
            }
            if (dOut < 10ULL * 1024 * 1024 * 1024) {
                totalDeltaOut += dOut;
            }
        }
    }
    
    _lastInMap = currentInMap;
    _lastOutMap = currentOutMap;
    _lastSampleTimestamp = now;
    
    @synchronized (self) {
        _downloadSpeedBytesPerSec = (double)totalDeltaIn / deltaTime;
        _uploadSpeedBytesPerSec = (double)totalDeltaOut / deltaTime;
        _sessionTotalDownloadBytes += totalDeltaIn;
        _sessionTotalUploadBytes += totalDeltaOut;
    }
}

@end
