//
//  NetworkMonitor.h
//  NetSpeedMonitor
//
//  Created for macOS (Apple Silicon M4 Native).
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface NetworkMonitor : NSObject

/// 当前下载速度（字节/秒）
@property (nonatomic, readonly) double downloadSpeedBytesPerSec;

/// 当前上传速度（字节/秒）
@property (nonatomic, readonly) double uploadSpeedBytesPerSec;

/// 本次应用运行期间累计下载总字节数
@property (nonatomic, readonly) uint64_t sessionTotalDownloadBytes;

/// 本次应用运行期间累计上传总字节数
@property (nonatomic, readonly) uint64_t sessionTotalUploadBytes;

/// 当前活跃网络接口名称 (例如 en0, en1)
@property (nonatomic, readonly, copy) NSString *activeInterfaceName;

/// 是否只统计物理网络接口 (en*, pdp_ip*)，避免代理/VPN (utun) 双重计数，默认为 YES
@property (nonatomic, assign) BOOL onlyPhysicalInterfaces;

/// 单例访问
+ (instancetype)sharedMonitor;

/// 触发一次网速数据采样并更新速度
- (void)sampleSpeed;

/// 重置本次会话累计流量统计
- (void)resetSessionCounters;

@end

NS_ASSUME_NONNULL_END
