//
//  main.m
//  NetSpeedMonitor
//
//  Created for macOS (Apple Silicon M4 Native).
//

#import <Cocoa/Cocoa.h>
#import "AppDelegate.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        NSApplication *app = [NSApplication sharedApplication];
        // 关键设置：作为 Accessory (Agent) 运行，确保 Dock 栏和应用切换栏完全无图标
        [app setActivationPolicy:NSApplicationActivationPolicyAccessory];
        
        AppDelegate *delegate = [[AppDelegate alloc] init];
        app.delegate = delegate;
        
        [app run];
    }
    return 0;
}
