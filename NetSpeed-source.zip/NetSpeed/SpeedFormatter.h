//
//  SpeedFormatter.h
//  NetSpeedMonitor
//
//  Created for macOS (Apple Silicon M4 Native).
//

#import <Cocoa/Cocoa.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, DisplayMode) {
    DisplayModeVerticalTwoLines = 0,    // 垂直双行模式 (默认，节省状态栏横向宽度)
    DisplayModeHorizontalSingleLine = 1  // 水平单行模式
};

typedef NS_ENUM(NSInteger, ArrowStyle) {
    ArrowStyleTriangle = 0,             // 三角箭头 ▲ ▼
    ArrowStyleSimple = 1                // 线性箭头 ↑ ↓
};

@interface SpeedFormatter : NSObject

/// 单例
+ (instancetype)sharedFormatter;

/// 格式化网速为规整字符串 (例如 @"12.5 KB/s", @" 1.8 MB/s")
- (NSString *)formatSpeed:(double)bytesPerSec;

/// 格式化总流量为易读字符串 (例如 @"125.4 MB", @" 1.25 GB")
- (NSString *)formatDataSize:(uint64_t)bytes;

/// 获取带箭头的完整单行文本 (例如 @"▲   2 KB/s" 或 @"▼  13 KB/s")
- (NSString *)formattedTextWithSpeed:(double)speed isUpload:(BOOL)isUpload arrowStyle:(ArrowStyle)arrowStyle;

/// 为状态栏按钮生成富文本 AttributedString
- (NSAttributedString *)attributedStatusBarTitleWithUploadSpeed:(double)upSpeed
                                                  downloadSpeed:(double)downSpeed
                                                    displayMode:(DisplayMode)displayMode
                                                     arrowStyle:(ArrowStyle)arrowStyle;

@end

NS_ASSUME_NONNULL_END
