//
//  AppDelegate.m
//  NetSpeedMonitor
//
//  Created for macOS (Apple Silicon M4 Native).
//

#import "AppDelegate.h"
#import "NetworkMonitor.h"
#import "SpeedFormatter.h"
#import "LaunchAtLogin.h"
#import "SpeedDisplayView.h"

static NSString * const kPrefDisplayMode = @"NetSpeedDisplayMode";
static NSString * const kPrefArrowStyle = @"NetSpeedArrowStyle";
static NSString * const kPrefRefreshInterval = @"NetSpeedRefreshInterval";
static NSString * const kPrefOnlyPhysical = @"NetSpeedOnlyPhysical";

static const CGFloat kStatusItemLengthVertical = 62.0;
static const CGFloat kStatusItemLengthHorizontal = 145.0;

@interface AppDelegate ()

@property (nonatomic, strong) NSStatusItem *statusItem;
@property (nonatomic, strong) NSMenu *statusMenu;
@property (nonatomic, strong) NSTimer *timer;
@property (nonatomic, strong) SpeedDisplayView *displayView;

// 实时数据显示菜单项
@property (nonatomic, strong) NSMenuItem *itemCurrentDown;
@property (nonatomic, strong) NSMenuItem *itemCurrentUp;
@property (nonatomic, strong) NSMenuItem *itemTotalDown;
@property (nonatomic, strong) NSMenuItem *itemTotalUp;
@property (nonatomic, strong) NSMenuItem *itemInterface;

// 设置项
@property (nonatomic, assign) DisplayMode displayMode;
@property (nonatomic, assign) ArrowStyle arrowStyle;
@property (nonatomic, assign) NSTimeInterval refreshInterval;

// 设置菜单引用以更新勾选状态
@property (nonatomic, strong) NSMenuItem *itemLaunchAtLogin;

@end


@implementation AppDelegate

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
    // 确保即使通过命令行启动也是纯 Accessory 状态（无 Dock 图标）
    [NSApp setActivationPolicy:NSApplicationActivationPolicyAccessory];
    
    // 加载偏好设置
    [self loadPreferences];
    
    // 初始化状态栏项：使用严格固定的长度，彻底杜绝网速数字变化导致状态栏左右推挤抖动
    CGFloat initialLength = (self.displayMode == DisplayModeVerticalTwoLines) ? kStatusItemLengthVertical : kStatusItemLengthHorizontal;
    self.statusItem = [[NSStatusBar systemStatusBar] statusItemWithLength:initialLength];
    self.statusItem.button.toolTip = @"NetSpeed 状态栏实时网速监控";
    self.statusItem.button.title = @"";
    
    // 添加自定义绘制视图到 statusItem.button，实现数学级精准垂直居中
    self.displayView = [[SpeedDisplayView alloc] initWithFrame:self.statusItem.button.bounds];
    [self.statusItem.button addSubview:self.displayView];
    
    // 构建菜单
    [self buildMenu];
    self.statusItem.menu = self.statusMenu;
    
    // 立即执行一次采样与 UI 更新
    [[NetworkMonitor sharedMonitor] sampleSpeed];
    [self updateStatusDisplay];
    
    // 启动定时器
    [self startTimer];
}

- (void)applicationWillTerminate:(NSNotification *)aNotification {
    [self.timer invalidate];
    self.timer = nil;
}

#pragma mark - 偏好设置

- (void)loadPreferences {
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    
    if ([ud objectForKey:kPrefDisplayMode]) {
        _displayMode = (DisplayMode)[ud integerForKey:kPrefDisplayMode];
    } else {
        _displayMode = DisplayModeVerticalTwoLines; // 默认垂直双行
    }
    
    if ([ud objectForKey:kPrefArrowStyle]) {
        _arrowStyle = (ArrowStyle)[ud integerForKey:kPrefArrowStyle];
    } else {
        _arrowStyle = ArrowStyleTriangle; // 默认三角箭头
    }
    
    if ([ud objectForKey:kPrefRefreshInterval]) {
        _refreshInterval = [ud doubleForKey:kPrefRefreshInterval];
    } else {
        _refreshInterval = 1.0; // 默认 1 秒
    }
    
    if ([ud objectForKey:kPrefOnlyPhysical]) {
        [NetworkMonitor sharedMonitor].onlyPhysicalInterfaces = [ud boolForKey:kPrefOnlyPhysical];
    } else {
        [NetworkMonitor sharedMonitor].onlyPhysicalInterfaces = YES;
    }
}

#pragma mark - 定时器与刷新

- (void)startTimer {
    [self.timer invalidate];
    self.timer = [NSTimer timerWithTimeInterval:self.refreshInterval
                                         target:self
                                       selector:@selector(timerTick:)
                                       userInfo:nil
                                        repeats:YES];
    // 加入 commonModes，保证在菜单打开或窗口拖拽时定时器依然稳定运行
    [[NSRunLoop currentRunLoop] addTimer:self.timer forMode:NSRunLoopCommonModes];
}

- (void)timerTick:(NSTimer *)timer {
    [[NetworkMonitor sharedMonitor] sampleSpeed];
    [self updateStatusDisplay];
}

- (void)updateStatusDisplay {
    NetworkMonitor *monitor = [NetworkMonitor sharedMonitor];
    SpeedFormatter *formatter = [SpeedFormatter sharedFormatter];
    
    NSString *upStr = [formatter formattedTextWithSpeed:monitor.uploadSpeedBytesPerSec
                                               isUpload:YES
                                             arrowStyle:self.arrowStyle];
    NSString *downStr = [formatter formattedTextWithSpeed:monitor.downloadSpeedBytesPerSec
                                                 isUpload:NO
                                               arrowStyle:self.arrowStyle];
    
    self.displayView.frame = self.statusItem.button.bounds;
    [self.displayView updateWithUpText:upStr
                              downText:downStr
                           displayMode:self.displayMode];
}

#pragma mark - 菜单构建

- (void)buildMenu {
    self.statusMenu = [[NSMenu alloc] initWithTitle:@"NetSpeedMenu"];
    self.statusMenu.delegate = self;
    
    // 实时数据展示项 (置灰只读)
    self.itemCurrentDown = [self createInfoMenuItemWithTitle:@"下载: --"];
    self.itemCurrentUp   = [self createInfoMenuItemWithTitle:@"上传: --"];
    self.itemTotalDown   = [self createInfoMenuItemWithTitle:@"本次下载: --"];
    self.itemTotalUp     = [self createInfoMenuItemWithTitle:@"本次上传: --"];
    self.itemInterface   = [self createInfoMenuItemWithTitle:@"活跃网卡: --"];
    
    [self.statusMenu addItem:self.itemCurrentDown];
    [self.statusMenu addItem:self.itemCurrentUp];
    [self.statusMenu addItem:[NSMenuItem separatorItem]];
    [self.statusMenu addItem:self.itemTotalDown];
    [self.statusMenu addItem:self.itemTotalUp];
    [self.statusMenu addItem:self.itemInterface];
    [self.statusMenu addItem:[NSMenuItem separatorItem]];
    
    // 显示模式子菜单
    NSMenuItem *displayModeItem = [[NSMenuItem alloc] initWithTitle:@"显示模式" action:nil keyEquivalent:@""];
    NSMenu *displaySubmenu = [[NSMenu alloc] init];
    
    NSMenuItem *itemVertical = [[NSMenuItem alloc] initWithTitle:@"垂直紧凑双行 (节省空间)" action:@selector(selectDisplayModeVertical:) keyEquivalent:@""];
    itemVertical.target = self;
    itemVertical.state = (self.displayMode == DisplayModeVerticalTwoLines) ? NSControlStateValueOn : NSControlStateValueOff;
    [displaySubmenu addItem:itemVertical];
    
    NSMenuItem *itemHorizontal = [[NSMenuItem alloc] initWithTitle:@"水平单行并排" action:@selector(selectDisplayModeHorizontal:) keyEquivalent:@""];
    itemHorizontal.target = self;
    itemHorizontal.state = (self.displayMode == DisplayModeHorizontalSingleLine) ? NSControlStateValueOn : NSControlStateValueOff;
    [displaySubmenu addItem:itemHorizontal];
    
    displayModeItem.submenu = displaySubmenu;
    [self.statusMenu addItem:displayModeItem];
    
    // 箭头符号子菜单
    NSMenuItem *arrowItem = [[NSMenuItem alloc] initWithTitle:@"箭头样式" action:nil keyEquivalent:@""];
    NSMenu *arrowSubmenu = [[NSMenu alloc] init];
    
    NSMenuItem *itemTri = [[NSMenuItem alloc] initWithTitle:@"三角箭头 (▲ ▼)" action:@selector(selectArrowTriangle:) keyEquivalent:@""];
    itemTri.target = self;
    itemTri.state = (self.arrowStyle == ArrowStyleTriangle) ? NSControlStateValueOn : NSControlStateValueOff;
    [arrowSubmenu addItem:itemTri];
    
    NSMenuItem *itemSimple = [[NSMenuItem alloc] initWithTitle:@"线性箭头 (↑ ↓)" action:@selector(selectArrowSimple:) keyEquivalent:@""];
    itemSimple.target = self;
    itemSimple.state = (self.arrowStyle == ArrowStyleSimple) ? NSControlStateValueOn : NSControlStateValueOff;
    [arrowSubmenu addItem:itemSimple];
    
    arrowItem.submenu = arrowSubmenu;
    [self.statusMenu addItem:arrowItem];
    
    // 刷新频率子菜单
    NSMenuItem *rateItem = [[NSMenuItem alloc] initWithTitle:@"刷新间隔" action:nil keyEquivalent:@""];
    NSMenu *rateSubmenu = [[NSMenu alloc] init];
    
    NSArray *rates = @[@(0.5), @(1.0), @(2.0)];
    NSArray *rateTitles = @[@"0.5 秒 (快速灵敏)", @"1.0 秒 (推荐默认)", @"2.0 秒 (极致省电)"];
    for (NSUInteger i = 0; i < rates.count; i++) {
        double val = [rates[i] doubleValue];
        NSMenuItem *rItem = [[NSMenuItem alloc] initWithTitle:rateTitles[i] action:@selector(selectRefreshInterval:) keyEquivalent:@""];
        rItem.target = self;
        rItem.representedObject = rates[i];
        rItem.state = (fabs(self.refreshInterval - val) < 0.01) ? NSControlStateValueOn : NSControlStateValueOff;
        [rateSubmenu addItem:rItem];
    }
    rateItem.submenu = rateSubmenu;
    [self.statusMenu addItem:rateItem];
    
    // 网卡模式子菜单
    NSMenuItem *interfaceItem = [[NSMenuItem alloc] initWithTitle:@"网卡统计范围" action:nil keyEquivalent:@""];
    NSMenu *interfaceSubmenu = [[NSMenu alloc] init];
    
    NSMenuItem *itemPhysical = [[NSMenuItem alloc] initWithTitle:@"仅物理网卡 (推荐，防代理流量翻倍)" action:@selector(toggleInterfaceMode:) keyEquivalent:@""];
    itemPhysical.target = self;
    itemPhysical.representedObject = @YES;
    itemPhysical.state = [NetworkMonitor sharedMonitor].onlyPhysicalInterfaces ? NSControlStateValueOn : NSControlStateValueOff;
    [interfaceSubmenu addItem:itemPhysical];
    
    NSMenuItem *itemAll = [[NSMenuItem alloc] initWithTitle:@"全部活动接口" action:@selector(toggleInterfaceMode:) keyEquivalent:@""];
    itemAll.target = self;
    itemAll.representedObject = @NO;
    itemAll.state = ![NetworkMonitor sharedMonitor].onlyPhysicalInterfaces ? NSControlStateValueOn : NSControlStateValueOff;
    [interfaceSubmenu addItem:itemAll];
    
    interfaceItem.submenu = interfaceSubmenu;
    [self.statusMenu addItem:interfaceItem];
    
    [self.statusMenu addItem:[NSMenuItem separatorItem]];
    
    // 重置统计
    NSMenuItem *resetItem = [[NSMenuItem alloc] initWithTitle:@"重置本次流量统计" action:@selector(resetStatistics:) keyEquivalent:@""];
    resetItem.target = self;
    [self.statusMenu addItem:resetItem];
    
    // 开机自启动
    self.itemLaunchAtLogin = [[NSMenuItem alloc] initWithTitle:@"开机自动启动" action:@selector(toggleLaunchAtLogin:) keyEquivalent:@""];
    self.itemLaunchAtLogin.target = self;
    self.itemLaunchAtLogin.state = [[LaunchAtLogin sharedManager] isEnabled] ? NSControlStateValueOn : NSControlStateValueOff;
    [self.statusMenu addItem:self.itemLaunchAtLogin];
    
    [self.statusMenu addItem:[NSMenuItem separatorItem]];
    
    // 关于
    NSMenuItem *aboutItem = [[NSMenuItem alloc] initWithTitle:@"关于 NetSpeed..." action:@selector(showAbout:) keyEquivalent:@""];
    aboutItem.target = self;
    [self.statusMenu addItem:aboutItem];
    
    // 退出
    NSMenuItem *quitItem = [[NSMenuItem alloc] initWithTitle:@"退出 NetSpeed" action:@selector(quitApp:) keyEquivalent:@"q"];
    quitItem.target = self;
    [self.statusMenu addItem:quitItem];
}

- (NSMenuItem *)createInfoMenuItemWithTitle:(NSString *)title {
    NSMenuItem *item = [[NSMenuItem alloc] initWithTitle:title action:nil keyEquivalent:@""];
    [item setEnabled:NO];
    return item;
}

#pragma mark - NSMenuDelegate (菜单即将打开时更新数据)

- (void)menuWillOpen:(NSMenu *)menu {
    NetworkMonitor *monitor = [NetworkMonitor sharedMonitor];
    SpeedFormatter *formatter = [SpeedFormatter sharedFormatter];
    
    NSString *downSpeedStr = [formatter formatSpeed:monitor.downloadSpeedBytesPerSec];
    NSString *upSpeedStr   = [formatter formatSpeed:monitor.uploadSpeedBytesPerSec];
    NSString *downTotalStr = [formatter formatDataSize:monitor.sessionTotalDownloadBytes];
    NSString *upTotalStr   = [formatter formatDataSize:monitor.sessionTotalUploadBytes];
    
    self.itemCurrentDown.title = [NSString stringWithFormat:@"当前下载速率:  %@", downSpeedStr];
    self.itemCurrentUp.title   = [NSString stringWithFormat:@"当前上传速率:  %@", upSpeedStr];
    self.itemTotalDown.title   = [NSString stringWithFormat:@"本次累计下载:  %@", downTotalStr];
    self.itemTotalUp.title     = [NSString stringWithFormat:@"本次累计上传:  %@", upTotalStr];
    self.itemInterface.title   = [NSString stringWithFormat:@"活动网络接口:  %@", monitor.activeInterfaceName ?: @"en0"];
    
    self.itemLaunchAtLogin.state = [[LaunchAtLogin sharedManager] isEnabled] ? NSControlStateValueOn : NSControlStateValueOff;
}

#pragma mark - 动作处理

- (void)selectDisplayModeVertical:(NSMenuItem *)sender {
    self.displayMode = DisplayModeVerticalTwoLines;
    self.statusItem.length = kStatusItemLengthVertical;
    [[NSUserDefaults standardUserDefaults] setInteger:self.displayMode forKey:kPrefDisplayMode];
    [self rebuildMenuStates];
    [self updateStatusDisplay];
}

- (void)selectDisplayModeHorizontal:(NSMenuItem *)sender {
    self.displayMode = DisplayModeHorizontalSingleLine;
    self.statusItem.length = kStatusItemLengthHorizontal;
    [[NSUserDefaults standardUserDefaults] setInteger:self.displayMode forKey:kPrefDisplayMode];
    [self rebuildMenuStates];
    [self updateStatusDisplay];
}

- (void)selectArrowTriangle:(NSMenuItem *)sender {
    self.arrowStyle = ArrowStyleTriangle;
    [[NSUserDefaults standardUserDefaults] setInteger:self.arrowStyle forKey:kPrefArrowStyle];
    [self rebuildMenuStates];
    [self updateStatusDisplay];
}

- (void)selectArrowSimple:(NSMenuItem *)sender {
    self.arrowStyle = ArrowStyleSimple;
    [[NSUserDefaults standardUserDefaults] setInteger:self.arrowStyle forKey:kPrefArrowStyle];
    [self rebuildMenuStates];
    [self updateStatusDisplay];
}

- (void)selectRefreshInterval:(NSMenuItem *)sender {
    self.refreshInterval = [sender.representedObject doubleValue];
    [[NSUserDefaults standardUserDefaults] setDouble:self.refreshInterval forKey:kPrefRefreshInterval];
    [self rebuildMenuStates];
    [self startTimer];
}

- (void)toggleInterfaceMode:(NSMenuItem *)sender {
    BOOL onlyPhysical = [sender.representedObject boolValue];
    [NetworkMonitor sharedMonitor].onlyPhysicalInterfaces = onlyPhysical;
    [[NSUserDefaults standardUserDefaults] setBool:onlyPhysical forKey:kPrefOnlyPhysical];
    [self rebuildMenuStates];
    [self updateStatusDisplay];
}

- (void)rebuildMenuStates {
    // 重新构建菜单勾选状态
    [self buildMenu];
    self.statusItem.menu = self.statusMenu;
}

- (void)resetStatistics:(id)sender {
    [[NetworkMonitor sharedMonitor] resetSessionCounters];
}

- (void)toggleLaunchAtLogin:(NSMenuItem *)sender {
    LaunchAtLogin *mgr = [LaunchAtLogin sharedManager];
    BOOL current = [mgr isEnabled];
    BOOL target = !current;
    NSError *error = nil;
    [mgr setEnabled:target error:&error];
    sender.state = [mgr isEnabled] ? NSControlStateValueOn : NSControlStateValueOff;
}

- (void)showAbout:(id)sender {
    NSAlert *alert = [[NSAlert alloc] init];
    alert.messageText = @"关于 NetSpeed Monitor";
    alert.informativeText = @"专为 macOS 与 Apple Silicon (M4) 打造的原生超轻量状态栏实时网速监视器。\n\n"
                            @"• 极低后台资源占用 (<0.05% CPU, ~6MB 内存)\n"
                            @"• 纯状态栏常驻，不占用 Dock 栏与切换器\n"
                            @"• 智能防代理翻倍与精确溢出处理\n"
                            @"版本: 1.0.0 (Native arm64)";
    [alert addButtonWithTitle:@"确定"];
    [alert runModal];
}

- (void)quitApp:(id)sender {
    [NSApp terminate:nil];
}

@end
