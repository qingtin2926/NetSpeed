//
//  LaunchAtLogin.h
//  NetSpeedMonitor
//
//  Created for macOS (Apple Silicon M4 Native).
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface LaunchAtLogin : NSObject

+ (instancetype)sharedManager;

/// 当前是否已开启开机自启动
- (BOOL)isEnabled;

/// 切换或设置开机自启动状态
- (BOOL)setEnabled:(BOOL)enabled error:(NSError * _Nullable * _Nullable)error;

@end

NS_ASSUME_NONNULL_END
