#!/usr/bin/env bash
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo "=========================================================="
echo "   NetSpeed Monitor - 极简 macOS 状态栏实时网速监控"
echo "   专为 Apple Silicon (M4 MacBook Air) 深度优化"
echo "=========================================================="
echo ""

echo "[1/3] 正在执行原生编译与打包..."
make all

echo ""
echo "[2/3] 正在安装至应用程序目录..."
if [ -w "/Applications" ]; then
    rm -rf "/Applications/NetSpeed.app"
    cp -R "build/NetSpeed.app" "/Applications/NetSpeed.app"
    TARGET_APP="/Applications/NetSpeed.app"
    echo "已成功安装至 /Applications/NetSpeed.app"
elif [ -d "$HOME/Applications" ] && [ -w "$HOME/Applications" ]; then
    rm -rf "$HOME/Applications/NetSpeed.app"
    cp -R "build/NetSpeed.app" "$HOME/Applications/NetSpeed.app"
    TARGET_APP="$HOME/Applications/NetSpeed.app"
    echo "已安装至 $HOME/Applications/NetSpeed.app"
else
    TARGET_APP="build/NetSpeed.app"
    echo "已在当前目录生成: build/NetSpeed.app"
fi

echo ""
echo "[3/3] 正在启动 NetSpeed..."
killall NetSpeedMonitor 2>/dev/null || true
open "$TARGET_APP"

echo ""
echo "=========================================================="
echo "🎉 启动成功！"
echo "• 观察屏幕顶部菜单栏（右上角），即可看到实时网速。"
echo "• 右下角（Dock 栏）完全不显示图标，不占任何运行位置。"
echo "• 点击菜单栏的网速文字，可切换显示样式、刷新率与开机自启。"
echo "=========================================================="
